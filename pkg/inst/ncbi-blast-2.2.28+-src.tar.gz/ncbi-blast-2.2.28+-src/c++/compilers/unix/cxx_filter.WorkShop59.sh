#! /bin/sh

# $Id: cxx_filter.WorkShop59.sh 154831 2009-03-16 15:27:44Z ucko $
# Authors:  Denis Vakatov, NCBI; Aaron Ucko, NCBI
#
# Temporary wrapper for the new central WorkShop redundant warning filter.

exec `dirname $0`/cxx_filter.WorkShop.sh
