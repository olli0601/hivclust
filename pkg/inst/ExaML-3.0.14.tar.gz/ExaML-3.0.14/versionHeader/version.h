#define programName        "ExaML"
#define programVersion     "3.0.14"
#define programVersionInt  3014
#define programDate        "June 25 2015"
